package com.ezeu.utils;

public class InvalidCoffeeOrQuantityException extends RuntimeException{
	
    public InvalidCoffeeOrQuantityException(String errorMessage) {
    	
        super(errorMessage);
        
    }
}
